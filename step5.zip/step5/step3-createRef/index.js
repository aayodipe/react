import React,{ Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    
    constructor(){
        super()
        this.state = {
            power : 0
        }
        this.powerInput = React.createRef();
        this.appTitle = React.createRef();
    }

    // powerChangeHandler = (evt) => {
    //     this.setState({
    //         power : evt.target.value
    //     })
    // }
    clickHandler = () => {
        this.setState({
            power : this.powerInput.current.value
        });
        this.appTitle.current.innerHTML = "Again and Again";
    }
    render(){
        return <div>
                <h1 ref={ this.appTitle }>Welcome to your life</h1>
                <h2>Power is : { this.state.power } </h2>
                <input ref={ this.powerInput } type="range"/>
                <button onClick={ this.clickHandler }>Click Me</button>
               </div>
    }
}

ReactDOM.render(<MainApp/> , document.querySelector("#root") );