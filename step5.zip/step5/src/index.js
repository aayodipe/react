import React,{ Component } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';

class MainApp extends Component{
    
    state = {
        title : 'React Users Application',
        users : []
    }
    componentDidMount(){
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((res) => {
            this.setState({
                users : res.data
            })
        }).catch((err) => {
            console.log("Error : ",err);
        })
    }
    render(){
        return <div>
                <h1>{ this.state.title }</h1>
                <ol>{
                        this.state.users.map( function(val, idx){
                            return <li>
                                Name : { val.name } | 
                                User Name : { val.username }
                                </li>
                        })

                    }</ol>
               </div>
    }
}

ReactDOM.render(<MainApp/> , document.querySelector("#root") );