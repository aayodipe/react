import { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
//     hero = {};
    constructor(){
        super()
        this.state = {
            username : 'Batman',
            usercity : 'Gotham',
            favcol : '#ff0000'
        }
    }
// Controlled / Uncontrolled Inputs

    nameChangeHandler = (evt) => {
        this.setState({
            username : evt.target.value
        })
    }
    cityChangeHandler = (evt) => {
        this.setState({
            usercity : evt.target.value
        })
    }
    colorChangeHandler = (evt) => {
        this.setState({
            favcol : evt.target.value
        })
    }
    render(){
        return <div>
                <h1>Welcome to your life</h1>
                <p>
                    UserName : { this.state.username } <br/>
                    UserCity : { this.state.usercity } <br/>
                    Fav Color : { this.state.favcol } <br/>
                </p>
                <fieldset>
                    <legend>User Registeration</legend>
                    <label> User Name 
                        <input onChange={ this.nameChangeHandler } value={ this.state.username } type="text" />
                    </label>
                    <br/>
                    <br/>
                    <label> User City 
                        <input onChange={ this.cityChangeHandler } value={ this.state.usercity } type="text" />
                    </label>
                    <br/>
                    <br/>
                    <label> User Fav Color 
                        <input onChange={ this.colorChangeHandler } value={ this.state.favcol } type="color" />
                    </label>
                    <br/>
                    <br/>
                    <label> User Mission 
                        <input defaultValue={ 'secret' } type="text" />
                    </label>
                </fieldset>
               </div>
    }
}

ReactDOM.render(<MainApp/> , document.querySelector("#root") );