import { Component } from "react";

    // shouldComponentUpdate
    // componentDidUpdate
class ChildComponent extends Component{
    constructor(){
        super();
        console.log("ChildComponent's Constructor was called");
        this.state = {
            initValue : 'Place Holder Text'
        }
    }

    static getDerivedStateFromProps(props, state){
        console.log("ChildComponent's getDerivedStateFromProps was called");
        console.log(props, state);
        return {
            initValue : props.message
        }
    }
    getSnapshotBeforeUpdate(){
        console.log(arguments.length, arguments[0], arguments[1]);
        console.log("ChildComponent's getSnapshotBeforeUpdate was called");
        return null
    }
    shouldComponentUpdate(){
        console.log("ChildComponent's shouldComponentUpdate was called");
        return false
    }
    componentDidUpdate(){
        console.log("ChildComponent's componentDidUpdate was called");
    }
    render(){
        console.log("ChildComponent's render was called");
        return <div>
                    <h2>Child's Power is { this.props.childPower }</h2>
                    <h1> I am Child Component's initValue : { this.state.initValue }</h1>
                </div> 
    }
}

export default ChildComponent;