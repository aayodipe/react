import { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComponent from './childcomp';

class MainApp extends Component{

// created : mounting
    // constructor
    // getDerivedStateFromProps (static)
    // render
    // componentDidMount

// modified : updating
    // getDerivedStateFromProps (static)
    // shouldComponentUpdate
    // render
    // getSnapshotBeforeUpdate
    // componentDidUpdate

// destroyed : unmounting 
    // componentWillUnmount

// errors : error handling
    // getDerivedStateFromError
    // componentDidCatch

constructor(){
    super();
    console.log("MainApp's Constructor was called");
    this.state = {
        title : 'Empty Title',
        power : 0
    }
    // this.clickHandler = this.clickHandler.bind(this)
}
clickHandler = () => {
    console.log(this.state.title);
}
static getDerivedStateFromProps(props, state){
    console.log("Props ", props);
    console.log("State ", state);
    // return {
    //     title : props.title
    // }
    console.log("MainApp's getDerivedStateFromProps was called");
    return true
}
componentDidMount(){
    console.log("MainApp's componentDidMount was called");
}
increasePower = () => {
    this.setState({
        power : this.state.power+1
    })
}
render(){
    console.log("MainApp's render was called");
        return <div>
                <h1>Main Application</h1>
                <h2> Power is : {this.state.power}</h2>
                <h2>Application Title : { this.state.title }</h2>
                <button onClick={ this.clickHandler }>Click Me</button>
                 <hr/>
                <button onClick={ this.increasePower }>Increase Power</button>
                 <ChildComponent message={ 'Hello Child Comp' }/>
               </div>
    }
}

ReactDOM.render(<MainApp title="Hero Application"/> , document.querySelector("#root") );