import React,{ Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './childComponent';

class MainApp extends Component{
    
    state = {
        power : 5
    }
    clickHandler = () => {
        this.setState({
            power : 10
        })
    }
    increaseHandler = () => {
        this.setState({
            power : this.state.power+1
        })
    }
    render(){
        return <div>
                <h1>Welcome to your life</h1>
                <h2> Power is : { this.state.power }</h2>
                <button onClick={ this.clickHandler }> Change Power to 10 </button>
                <button onClick={ this.increaseHandler }> Increase Power </button>
                <hr/>
                <ChildComp pow={ this.state.power }/>
               </div>
    }
}

ReactDOM.render(<MainApp/> , document.querySelector("#root") );