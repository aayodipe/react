import { PureComponent } from 'react';

class ChildComp extends PureComponent{
    constructor(){
        super();
        this.state = {
            parentPow : 0
        }
    }
    // static getDerivedStateFromProps(props, state){
    //     return {
    //         parentPow : props.pow
    //     }
    // }
    // shouldComponentUpdate(props){
    //     if( props.pow === this.state.parentPow ){
    //         return false
    //     }else{
    //         return true
    //     }
    // }
    render(){
        console.log(" The Child Component Rendered ")
        return <div>
            <h2> Child Component </h2>
            <h2> state.parentPow : { this.state.parentPow }</h2>
            <h2> Power applied is : { this.props.pow }</h2>
        </div>
    }
}

export default ChildComp;
