import { useState } from 'react';
function useBool(initVal = false){
    const [state, setState] = useState(initVal);
    const bool = () => {
        setState(!state);
    }
    return [state, bool];
}
export default useBool;