/* import { useState } from "react";

function CustomHookEx(){
    let [ agree, changeOpenion ] = useState(false);
    return <div>
            <h1> Agree to Terms </h1>
            <h2> Agree to terms : { agree ? 'Agree' : 'Dont Agree'  }</h2>
            <button onClick={ () => { changeOpenion( agree = !agree) }}>Change Openion</button>
          </div>
}
export default CustomHookEx; */


import useBool from "../hooks/useBool";

function CustomHookEx(){
    let [ agree, changeOpenion ] = useBool(false);
    let [ lang, changeLanguage ] = useBool(false);
    
    return <div>
            <h1> Agree to Terms </h1>
            <h2> Agree to terms : { agree ? 'Agree' : 'Dont Agree'  }</h2>
            <h2> Default Language : { lang ? 'French' : 'English'  }</h2>
            <button onClick={ () => { changeOpenion() }}>Change Openion</button>
            <button onClick={ () => { changeLanguage() }}>Change Language</button>
          </div>
}
export default CustomHookEx;