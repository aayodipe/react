/* import { useState } from 'react';
function PowerEnhancer(){
    let [ power, updatePower ] = useState(0);
    return <div>
            <h1> Function Component </h1>
            <h2> Power is : { power }</h2>
            <button onClick={ () => { updatePower( power + 1 ) }}>Increase Power</button>
          </div>
}
export default PowerEnhancer; */
//--------------------------------------------------

/* import { useState } from 'react';
function PowerEnhancer(){
    let [ power, updatePower ] = useState(0);
    return <div>
            <h1> Function Component </h1>
            <h2> Power is : { power }</h2>
            <button onClick={ () => { updatePower( oldpower => oldpower+1 ) }}>Increase Power</button>
          </div>
}
export default PowerEnhancer; */

//--------------------------------------------------

import { useState } from 'react';
function PowerEnhancer(){
    let [ hero, updateHero ] = useState({ title : '', power : 0 });
    return <div>
            <h1> Function Component </h1>
            <h2> Hero Title : { hero.title }</h2>
            <h2> Hero Power : { hero.power }</h2>
            <button onClick={ () => { updateHero( { ...hero, title : 'Updated Title' } ) }}>Change Title</button>
            <button onClick={ () => { updateHero( { ...hero, power : hero.power + 1 } ) }}>Increase Power</button>
          </div>
}
export default PowerEnhancer;