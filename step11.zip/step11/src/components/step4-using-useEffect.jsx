import {useState, useEffect} from 'react';
function UseEffectEx(){
    let [ power, changePower ] = useState(0);

    useEffect( function(){
        console.log("UseEffect Called");
    });

    return <div>
                <h1>Using useEffect Hook</h1>
                <h2>Power is : { power } </h2>
                <button onClick={ ()=> {changePower(Math.round(Math.random() * 100))} }>Change Power</button>
           </div>
}

export default UseEffectEx