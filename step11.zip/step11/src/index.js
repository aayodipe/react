import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ClassComp from './components/step1.class-comp';
import PowerEnhancer from './components/step2-useStatehook';
import CustomHookEx from './components/step3-useCustomHook';
import UseEffectEx from './components/step4-using-useEffect';

class MainApp extends Component{
  render(){
    return <div>
      <h1> Hooks 101 </h1>
      <hr/>
      <ClassComp/>
      <PowerEnhancer/>
      <CustomHookEx/>
      <UseEffectEx/>
    </div>
  }
}

ReactDOM.render(<MainApp/>,
  document.getElementById('root')
)