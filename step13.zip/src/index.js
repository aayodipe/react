import React from 'react';
import ReactDOM from 'react-dom';
import GrandParent from './components/grandparent.component';



ReactDOM.render(<GrandParent/>,
  document.getElementById('root')
);
