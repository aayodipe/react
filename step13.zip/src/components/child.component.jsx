import { Component } from "react";
import { FamilyConsumer } from "../family.context";

class ChildComp extends Component{
    state = {
        message : "Hello From Childs Component"
    }
    render(){
        return <div>
                    <h1>Child Component</h1>
                    <FamilyConsumer>
                        { (value) => {
                            return <h1> { value } </h1>
                        }}
                    </FamilyConsumer>
               </div>
    }
}

export default ChildComp;