import { Component } from "react";
import { FamilyConsumer } from "../family.context";

class CousinComp extends Component{
    state = {
        message : "Hello From Cousin Component"
    }
    render(){
        return <div>
                    <h1>Cousin Component</h1>
                    <FamilyConsumer>
                        { (value) => {
                            return <h1> { value } </h1>
                        }}
                    </FamilyConsumer>
               </div>
    }
}

export default CousinComp;