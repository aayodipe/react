import { Component } from "react";
import { FamilyProvider } from "../family.context";
import CousinComp from "./cousin.component";
import Parent from "./parent.component";

class GrandParent extends Component{
    state = {
        message : "Hello From Grand Parent Component"
    }
    updateInfo = () =>{
        this.setState({
            message : 'Secret code is : '+Math.round(Math.random() * 1000 )
        })
    }
    render(){
        return <FamilyProvider value={ this.state.message }>
                <div>
                        <h1>Grand Parent Component</h1>
                        <button onClick={ this.updateInfo }>Generate Message</button>
                        <Parent/>
                </div>
                <CousinComp/>
            </FamilyProvider>
    }
}

export default GrandParent;