import { Component } from "react";
import ChildComp from "./child.component";

class Parent extends Component{
    state = {
        message : "Hello From Parent Component"
    }
    render(){
        return <div>
                    <h1>Parent Component</h1>
                    <ChildComp/>
               </div>
    }
}

export default Parent