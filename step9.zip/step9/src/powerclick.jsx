import { Component } from "react";
import UpdatedWithBoost from "./withBoost";

class PowerClick extends Component{
    
    render(){
        return <div>
                    <h1>Power is : { this.props.power }</h1>
                    <h2> Company Name : { this.props.compname }</h2>
                    <h3>Team : { this.props.team }</h3>
                    <button onClick={ this.props.boostpower }>Click to Increase Power</button>
                </div>
    }
}

export default UpdatedWithBoost( PowerClick )