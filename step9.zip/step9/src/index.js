import { Component } from 'react';
import ReactDOM from 'react-dom';
import PowerClick from './powerclick';
import SpeedBoost from './speedboost';

class MainApp extends Component{
    render() {
        return  <div>
                    <h1>Hello HOC</h1>
                    <PowerClick team="Avengers" />
                    <SpeedBoost team="Justice League"/>
                </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"))