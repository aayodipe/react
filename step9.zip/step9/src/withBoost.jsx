import { Component } from "react"

const UpdatedWithBoost = (OriginalComponent) => {
    return class NewComponent extends Component{
        constructor(){
            super();
            this.state = {
                power : 0
            }
        }
        boostPower = () => {
            this.setState(function(prevState){
                return {
                    power : prevState.power+1
                }
            })
        }

        render(){
            return <OriginalComponent 
            power={ this.state.power } 
            boostpower={ this.boostPower } 
            {...this.props} compname="mycompany"/>
        }
    }
}

export default UpdatedWithBoost;