import { Component } from "react";
import UpdatedWithBoost from "./withBoost";

class SpeedBoost extends Component{
    
    render(){
        return <div>
                    <h1>Power is : { this.props.power }</h1>
                    <h2> Company Name : { this.props.compname }</h2>
                    <h3>Team : { this.props.team }</h3>
                    <div style={ { 
                        width : '250px', 
                        height : '50px', 
                        backgroundColor : 'orange',
                        border : '1px solid silver',
                        textAlign : 'center',
                        lineHeight : '50px'} }
                        onMouseMove={ this.props.boostpower }
                    > Speed Boost </div>
                </div>
    }
}

export default UpdatedWithBoost( SpeedBoost )