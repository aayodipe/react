import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ClassPowerEnhancer from './components/before-useEffectHook';
import UsingAjaxAxios from './components/using-axios-class-component';
import UseEffectCounter from './components/using-useEffectHook';
import UseEffectWithAjax from './components/using-useEffectwith-api';

class MainApp extends Component{
  state = {
    show : true
  }
  render() {
    return <div>
             <h1>Hooks 101</h1>
             <button onClick={ ()=>{ this.setState({ show : !this.state.show }) }}>Show / Hide</button>
             { this.state.show && <ClassPowerEnhancer/> }
             <hr/>
             { this.state.show && <UseEffectCounter/> }
             <hr/>
             <UseEffectWithAjax/>
             <hr/>
             <UsingAjaxAxios/>
    </div>;
  }
}

ReactDOM.render(<MainApp/>,
  document.getElementById('root')
)