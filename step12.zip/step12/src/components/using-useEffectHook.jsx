import { useState, useEffect } from 'react';
function UseEffectCounter(){
   let [count, changeCount ] = useState(0);
   let [power, changePower ] = useState(0);
   useEffect(()=>{
       console.log("Function Component Loaded : ", "Power : "+power, "Count : "+count);
        return () =>{
            console.log("Function Component UnMounted");
        }
    },[count]); // dependency array can take props and state

/*  useEffect(()=>{
       console.log("Function Component Loaded : ", "Power : "+power, "Count : "+count);
    },[]); // dependency array can take props and state
   useEffect(()=>{
       console.log("Function Component Loaded : ", "Power : "+power, "Count : "+count);
    },[count]); // dependency array can take props and state
   useEffect(()=>{
    return () =>{
        console.log("Function Component UnMounted");
    }
    },[]); // dependency array can take props and state */
    return <div>
                <h1>Hello from Function Component</h1>
                <h2>Count Value : { count }</h2>
                <h2>Power Value : { power }</h2>
                <button onClick={ ()=> changeCount( count + 1 ) }>Change Count</button>
                <button onClick={ ()=> changePower( power + 1 ) }>Change Power</button>
           </div>
}
export default UseEffectCounter;