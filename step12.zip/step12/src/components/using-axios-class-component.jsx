import { Component } from 'react';
import axios from 'axios';

class UsingAjaxAxios extends Component{
    state = {
        posts : []
    }
    componentDidMount(){
        axios.get("http://jsonplaceholder.typicode.com/posts")
        .then( res => {
            this.setState({
                posts : res.data
            });
        }).catch( error => {
            console.log("Error : ", error );
        })
    }
    render(){
        return <div>
                <h1> Class Component with Axios </h1>
                <ul>
                    {
                        this.state.posts.map( post => {
                            return <li key={post.id}>{ post.title }</li>
                        } )
                    }
                </ul>
            </div>
    }
}

export default UsingAjaxAxios;