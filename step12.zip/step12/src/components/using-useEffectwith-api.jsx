import { useState, useEffect } from 'react';
import axios from 'axios';

function UseEffectWithAjax(){
    let [ posts, setPosts ] = useState([]);
    useEffect( () => {
        axios.get("http://jsonplaceholder.typicode.com/posts")
        .then( res => {
            setPosts(res.data);
        }).catch( error => {
            console.log("Error : ", error );
        })
    },[]);

    return <div>
                <h1>Using UseEffect Hook with Ajax</h1>
                <ul>
                    {
                        posts.map( post => {
                            return <li key={post.id}>{ post.title }</li>
                        } )
                    }
                </ul>
            </div>    
}

export default UseEffectWithAjax;