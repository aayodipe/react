import { Component } from "react";

class ClassPowerEnhancer extends Component{
    state = {
        count : 0
    }
    componentDidMount(){
        console.log("component did mount")
        document.getElementById("log").innerHTML = "Class Component Loaded";
    }
    componentDidUpdate(){
        console.log("component did update")
        document.getElementById("log").innerHTML = "Class Component Updated";
    }
    componentWillUnmount(){
        console.log("component did unmount")
        document.getElementById("log").innerHTML = "Class Component Unmounted";
    }
    render(){
        return <div>
                    <h1>Hello From Class Component</h1>
                    <h2>Count Value : { this.state.count }</h2>
                    <button onClick={() => { this.setState( { count : this.state.count + 1 } ) }}>Click to change count</button>
               </div>
    }
}

export default ClassPowerEnhancer