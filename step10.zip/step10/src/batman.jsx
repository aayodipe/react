import { Component } from "react";

class BatmanComp extends Component{
    render(){
        return <h1>You are Looking at Batman Component</h1>
    }
}

export default BatmanComp;