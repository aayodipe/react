import { Component } from "react";

class HomeComp extends Component{
    render(){
        return <h1>You are Looking at Home Component</h1>
    }
}

export default HomeComp;