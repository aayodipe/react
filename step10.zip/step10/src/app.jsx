import { Component } from "react";
import { BrowserRouter, Link, Route, Switch } from 'react-router-dom';
import BatmanComp from "./batman";
import HomeComp from "./home";
import NotFoundComp from "./notfound";
import SupermanComp from "./superman";

let defaultQty = 250;

class AppComp extends Component{
    render(){
        return <div>
                    <h1>React Routing Example</h1>
                    <hr/>
<BrowserRouter>
    <ul>
        <li> <Link to="/">Home</Link> </li>
        <li> <Link to="/batman">Batman</Link> </li>
        <li> <Link to={ "/superman/"+defaultQty } >Superman</Link> </li>
    </ul>
    <Switch>
        <Route path="/" exact component={ HomeComp }/>
        <Route path="/batman" component={ BatmanComp }/>
        <Route path="/superman/:qty" component={ SupermanComp }/>
        <Route component={ NotFoundComp }/>
    </Switch>
</BrowserRouter>
               </div>
    }
}

export default AppComp;