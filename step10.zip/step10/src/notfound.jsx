import { Component } from "react";

class NotFoundComp extends Component{
    render(){
        return <h1>404 : Requested page not found</h1>
    }
}

export default NotFoundComp;