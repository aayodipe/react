import { Component } from "react";

class SupermanComp extends Component{
    render(){
        return <h1>You are Looking at Superman Component : Quantity { this.props.match.params['qty']}</h1>
    } 
}

export default SupermanComp;