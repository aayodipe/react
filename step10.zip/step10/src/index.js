import React from 'react';
import ReactDOM from 'react-dom';
import AppComp from './app';


ReactDOM.render(<AppComp/>,
  document.getElementById('root')
);