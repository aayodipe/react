const { Component } = require("react");

class FriendList extends Component{
    constructor(){
        super();
        this.state = {
            friendslist : []
        }
    }
    componentDidMount(){
        
    }
    render(){
        return <div className="container">
            <h1>Online Friends List</h1>
            <ol>{
                 this.state.friendslist.map( (val, idx) => {
                     return <li key={ idx }>{val.name}</li>
                 })
                }
            </ol>
        </div>
    }
}

export default FriendList;