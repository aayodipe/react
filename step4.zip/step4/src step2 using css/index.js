import { Component } from 'react';
import ReactDOM from 'react-dom';
import "./mystyle.css";
import cssmod from "./stylefile.module.css";
/*
1 standard style sheets like css, sass, scss
2 inline style
3 in file style
4 css modules
5 Emotion (external css framework)
6 Radium
*/
class MainApp extends Component{
    render(){
        let myinfilestyle = {
            backgroundColor : "darkblue",
            color : "cornsilk",
            fontFamily : "Arial",
            padding : "10px"
        }
        return <div>
            <h1>Main Application</h1>
            <p className="player">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum dictum mauris nec dolor mattis blandit eget at magna. Sed vestibulum at nisi vitae luctus. Nullam viverra lacus vitae venenatis fermentum. Etiam interdum magna eros, sit amet vehicula mi imperdiet dapibus. Donec eget mollis massa. Sed congue facilisis varius. Phasellus ut sodales quam, a fringilla diam. Maecenas ornare vestibulum finibus. Aenean ultricies id ex vitae efficitur. Nulla facilisi. Mauris aliquam ipsum id pulvinar pretium. Phasellus ut dictum nisi. Nullam in volutpat dui, vitae interdum mi. 
            </p>
            <p style={ { color : "cornsilk", backgroundColor : "crimson", fontFamily : "Arial", padding : "10px" } }>
                Vivamus quis tortor mi. Proin ac leo nec elit condimentum auctor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin vestibulum lectus at urna bibendum aliquam. Morbi a augue id est aliquet sollicitudin. Etiam bibendum nunc eget purus lacinia, nec lacinia tellus euismod. Nunc tempus, lectus sed facilisis auctor, velit arcu commodo ante, consequat eleifend nibh sem sit amet nisi. Vestibulum pretium, ligula eu dictum venenatis, enim enim finibus felis, ut efficitur est nisi a lectus. Etiam sed tempus nulla. In finibus at mi in faucibus. Vivamus auctor sagittis iaculis. Vestibulum facilisis vel leo consectetur suscipit.  
            </p>
            <p style={ myinfilestyle }>
                Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Morbi nunc mauris, vestibulum ut orci ac, consectetur fringilla metus. Donec sed lacus et quam placerat porttitor non quis nibh. Mauris eu aliquet ex, nec aliquet lectus. Nulla elementum dolor lacus, blandit tempus lectus posuere vel. Fusce massa nulla, vestibulum a fermentum non, pretium vitae tortor. Nullam malesuada arcu quis nisl iaculis pulvinar. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.  
            </p>
            <p className={ cssmod.player }>
                Curabitur porttitor neque sit amet justo dapibus fringilla. Aenean vitae porttitor est, id pharetra diam. Vestibulum ligula ante, feugiat at massa ac, maximus iaculis odio. Suspendisse fermentum massa sed tortor rhoncus venenatis. Interdum et malesuada fames ac ante ipsum primis in faucibus. Cras ut enim accumsan, luctus justo vel, dictum erat. Aenean eget placerat purus. Fusce lobortis velit velit, eget luctus mauris accumsan vel. Sed libero justo, posuere ac turpis ut, tempus porttitor ligula. 
            </p>
        </div>
    }
}

ReactDOM.render(<MainApp/> , document.querySelector("#root") );