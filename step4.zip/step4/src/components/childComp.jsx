import { Component } from "react";

class ChildComp extends Component{
    constructor(){

    }

    render(){
        return <h1> Child Component </h1>
    }
}

export default ChildComp;