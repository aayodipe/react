import { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{

// created : mounting
    // constructor
    // getDerivedStateFromProps (static)
    // render
    // componentDidMount

// modified : updating
    // getDerivedStateFromProps (static)
    // shouldComponentUpdate
    // render
    // getSnapshotBeforeUpdate
    // componentDidUpdate

// destroyed : unmounting 
    // componentWillUnmount

// errors : error handling
    // getDerivedStateFromError
    // componentDidCatch

constructor(){
    super();
    console.log("MainApp's Constructor was called");
    this.state = {
        title : 'Empty Title'
    }
    // this.clickHandler = this.clickHandler.bind(this)
}
clickHandler = () => {
    console.log(this.state.title);
}
static getDerivedStateFromProps(props, state){
    console.log("Props ", props);
    console.log("State ", state);
    // return {
    //     title : props.title
    // }
    console.log("MainApp's getDerivedStateFromProps was called");
    return true
}
componentDidMount(){
    console.log("MainApp's componentDidMount was called");
}
render(){
    console.log("MainApp's render was called");
        return <div>
                <h1>Main Application</h1>
                <h2>Application Title : { this.state.title }</h2>
                <button onClick={ this.clickHandler }>Click Me</button>
               </div>
    }
}

ReactDOM.render(<MainApp title="Hero Application"/> , document.querySelector("#root") );