import { Component } from "react";

class ChildApp extends Component{
    state = {
        tempMessage : "Default Message",
        parentMessage : "child comp says hi"
    }
    render(){
        return <div style={ {border : "2px solid black",padding : "10px", margin : "10px"}}>
                    <h1>Child Application</h1>
                    <h2>Message from Parent : { this.props.childMessage }</h2>
                    <h2>Child's Message value : { this.state.tempMessage }</h2>
                    <button onClick={ () => {
                        this.setState({
                            tempMessage : this.props.childMessage
                        })
                    } }>Add Prop value to State value</button>

                    <button onClick={ () =>{
                        this.props.handlerFunction( this.state.parentMessage )
                    } }>Click to send message</button>
               </div>
    }
}
export default ChildApp;