import { Component } from "react";
import ChildApp from "./childapp";

class MainApp extends Component{
    state = {
        message : "Welcome to your life",
        tempMessage : "Default Value"
    }
    changeTempMessage = (messageEvent) => {
        this.setState({
            tempMessage : messageEvent
        })
    }
    render(){
        return <div>
            <h1> Main Application Component </h1>
            <h2>Temp Message Value : { this.state.tempMessage }</h2>
            <ChildApp handlerFunction={ this.changeTempMessage } 
            childMessage={ this.state.message } />
        </div>
    }
}

export default MainApp;