import ReactDOM from 'react-dom';
import MainApp from './components/mainapp';

ReactDOM.render(<MainApp/> , document.querySelector("#root") );