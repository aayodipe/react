import { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        // setState({})
        // setState({}, callback)
        // setState(callback, callback)

        // Step 1 using setState({})
        /*
        this.setState({
            power : this.state.power + 1
        }
        console.log(this.state.power);
        */

        // Step 2 using setState({}, callback)
        /*
        this.setState({
            power : this.state.power + 1
        }, function(){
            console.log(this.state.power);
        });
        */
       
        // Step 3 using setState(callback, callback)
        this.setState(function(previousState, props){
            // console.log(previousState, props);
            return {
                power : previousState.power + 1
            }
        }, function(){
            console.log(this.state.power);
        })
     }
render(){
        
        return <div>
                <h1>Main Application</h1>
                <h2>Power is : { this.state.power }</h2>
                <h3>Title is : {this.props.title}</h3>
                <button onClick={ this.increasePower }>Increase Power</button>
            </div>
    }
}

ReactDOM.render(<MainApp title="hello there"/> , document.querySelector("#root") );