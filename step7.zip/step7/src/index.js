import React, { Component } from 'react';
import ReactDOM from 'react-dom';

//-----------------------------------
class PopUp extends Component{

   constructor(){
    super();
    this.element = document.createElement("div");
    this.element.setAttribute("className", "popup");
    // this.element.innerHTML = "<button> hello there </button>";
    this.btn = document.createElement("button");
    this.btn.innerText = " X ";

}
   componentDidMount(){
    this.element.appendChild(this.btn);
    document.getElementById("popup").appendChild(this.element);
   }
   componentWillUnmount(){
    document.getElementById("popup").removeChild(this.element);
   }

    render(){

        return ReactDOM.createPortal(
        this.props.children, 
        this.element)
    }
}


//-----------------------------------


class MainApp extends Component{

    state = { showHideModel : false };

    manageShowPopup = () => {
        this.setState({ showHideModel : true });
    }
    manageHidePopup = () => {
        this.setState({ showHideModel : false });
    }
    render(){
        if(this.state.showHideModel){
            return <PopUp>
                        <div>
                            Hello Friends <button onClick={ this.manageHidePopup }>Close Popup</button>
                        </div>
                    </PopUp>
        }else{
            return <div>
                        Show Popup <button onClick={ this.manageShowPopup }>Show Popup</button>
                   </div>
        }
    }
        
}

ReactDOM.render(<MainApp/>, document.getElementById("root"))