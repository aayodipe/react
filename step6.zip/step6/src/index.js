import { Component } from 'react';
import ReactDOM from 'react-dom';
import FriendList from './friendslist';

class MainApp extends Component{
    render() {
        return (
            <div>
                <h1>Hello CRUD</h1>
                <FriendList/>
            </div>
             
        );
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"))