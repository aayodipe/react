import { Component } from 'react';
import axios from 'axios';

class FriendList extends Component{
    constructor(){
        super();
        this.state = {
            friendslist : [],
            name : '',
            city : '',
            age : '',
            ename : '',
            ecity : '',
            eage : '',
            showEditBox : false
        }
    }
    componentDidMount(){
        this.refresh();
    }
    //-------------------------------------
    refresh = () =>{
        axios.get("http://localhost:3030/data").then((res) => {
            this.setState({
                friendslist : res.data
            })
        })
    }
    //-------------------------------------
    nameHandler = (evt) => {
        this.setState({
            name : evt.target.value
        })
    }
    cityHandler = (evt) => {
        this.setState({
            city : evt.target.value
        })
    }
    ageHandler = (evt) => {
        this.setState({
            age : evt.target.value
        })
    }
    addFriendHandler = (evt) =>{
        evt.preventDefault();
        axios.post("http://localhost:3030/add", {
            name : this.state.name,
            city : this.state.city,
            age : this.state.age,
        }).then((res) => {
            console.log(res);
            this.refresh();
            this.setState({
                 name : "",
                 city : "",
                 age : "",
             })
        }).catch( error => console.log(error))
    }
    editHandler = (fid) => {
        // console.log(fid);
        axios.get("http://localhost:3030/edit/"+fid).then( res => {
                this.setState({
                    ename : res.data.name,
                    ecity : res.data.city,
                    eage : res.data.age,
                    showEditBox  : true
                });

        })
    }
    deleteHandler = (fid) => {
        axios.delete("http://localhost:3030/delete/"+fid).then((res) => {
            console.log(res.data);
            this.refresh();
        }).catch(error => console.log(error))
        console.log(fid);
    }
    //-------------------------------------
    render(){
        return <div className="container">
            <h1>Online Friends List</h1>
            <hr/>
            <h1>Add New Friend</h1>
            <form action="">
                <table>
                    <tbody>
                    <tr>
                        <td>
                            <label htmlFor="fname">Friend's Name</label>
                        </td>
                        <td>
                            <input name="fname" onChange={this.nameHandler} value={ this.state.name } id="fname" type="text"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label htmlFor="fcity">Friend's City</label>
                        </td>
                        <td>
                            <input name="fcity" onChange={this.cityHandler} value={ this.state.city } id="fcity" type="text"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label htmlFor="fage">Friend's Age</label>
                        </td>
                        <td>
                            <input name="fage" onChange={this.ageHandler} value={ this.state.age } id="fage" type="text"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            
                        </td>
                        <td>
                            <button onClick={ this.addFriendHandler }>Add Friend</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
            <hr/>
            <ol>{
                 this.state.friendslist.map( (val, idx) => {
                   //  console.log(val);
                     return <li key={ idx }>
                         <button onClick={ ()=>{
                             this.editHandler(val._id)
                         } }> EDIT </button>
                         &nbsp; &nbsp;
                         <button onClick={ () =>{
                             this.deleteHandler(val._id);
                         } }> DELETE </button>
                         &nbsp; &nbsp;
                         Friend's Name : {val.name} | 
                         Friend's City : {val.city} | 
                         Friend's Age : {val.age} |
                         </li>
                 })
                }
            </ol>
            <hr/>
            {
                this.state.showEditBox &&  <div>
                <table>
                        <tbody>
                        <tr>
                            <td>
                                <label htmlFor="fname">Friend's Name</label>
                            </td>
                            <td>
                                <input name="fname" onChange={this.editNameHandler} value={ this.state.ename } id="fname" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label htmlFor="fcity">Friend's City</label>
                            </td>
                            <td>
                                <input name="fcity" onChange={this.editCityHandler} value={ this.state.ecity } id="fcity" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label htmlFor="fage">Friend's Age</label>
                            </td>
                            <td>
                                <input name="fage" onChange={this.editAgeHandler} value={ this.state.eage } id="fage" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                
                            </td>
                            <td>
                                <button onClick={ this.addFriendHandler }>Add Friend</button>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            }
            
        </div>
    }
}

export default FriendList;
