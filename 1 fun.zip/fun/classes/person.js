export class Person{
    constructor(ncity){
        this.city = ncity;  
    }
}