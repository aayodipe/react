import ReactDOM from 'react-dom';
import App, { FirstComp } from './app';


ReactDOM.render(<App/>, 
document.getElementById("root"));