import { Component } from "react";

class ErrorManager extends Component{
    // componentDidCatch
    state = {
        hasError : false
    }
    static getDerivedStateFromError(){
        return {
            hasError : true
        }
    }
    render(){
        if(this.state.hasError){
            return <h3>Error Was Reported</h3>
        }else{
            return this.props.children;
        }
    }
}
export default ErrorManager;