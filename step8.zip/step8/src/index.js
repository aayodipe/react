import { Component } from 'react';
import ReactDOM from 'react-dom';
import ErrorManager from './errorManager';
import Player from './players';

class MainApp extends Component{
    render() {
        return (
            <div>
                <h1>Handling Error In UI </h1>
                <hr/>
                <ErrorManager>
                    <Player power="4"/>
                </ErrorManager>
                <ErrorManager>
                    <Player power="5"/>
                </ErrorManager>
                <ErrorManager>
                    <Player power="6"/>
                </ErrorManager>
                <ErrorManager>
                    <Player power="7"/>
                </ErrorManager>
            </div>
             
        );
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"))