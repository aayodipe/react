import { Component } from "react";

class Player extends Component{
    render(){
        if( this.props.power < 5 ){
            throw new Error('Your power is less to participate')
        }else{
             return <h1> I am a Player Power is :  { this.props.power } </h1>
        }

    }
}

export default Player;